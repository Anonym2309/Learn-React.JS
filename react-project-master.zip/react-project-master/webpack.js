exports.ServerConfig = require('./lib/webpack.server.config').default
exports.ClientConfig = require('./lib/webpack.client.config').default

