create-react-project
====================

Create's new [React Projects](https://github.com/ryanflorence/react-project)

```sh
npm install create-react-project -g
create-react-project your-amazing-app
```

