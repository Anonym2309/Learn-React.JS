import React from 'react'

export default React.createClass({
  render() {
    return (
      <div>404</div>
    )
  }
})

